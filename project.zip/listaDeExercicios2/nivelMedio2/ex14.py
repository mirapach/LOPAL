# Crie um programa que peça ao usuário para digitar o nome de itens de supermercado.
# O programa deve parar de pedir quando o usuário digitar `"sair"`
# Ao final, exiba todos os itens adicionados à lista
