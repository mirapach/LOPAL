# Dada uma lista pré-definida com 5 e-mails (ex: ["teste@gmail.com", "admin@escola.br", "prof@escola.br"])
# Use um laço for para exibir apenas os e-mails que terminam com o domínio @escola.br.
