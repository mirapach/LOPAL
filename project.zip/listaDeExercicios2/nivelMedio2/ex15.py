# Solicite que o usuário digite uma frase.
# Usando um laço `for`, percorra a string e conte quantas vogais (a, e, i, o, u) a frase possui, exibindo o total no final.
