subtotal = 0.0

for i in range(1, 6):
    preco = float(input(f"Digite o preço do produto{i}: R$ "))
    subtotal += preco

imposto = subtotal * 0.10
valor_final = subtotal + imposto

# Resumo da compra

print(f"Subtotal: R${subtotal:.2f}")
print(f"Imposto (10%): R$ {imposto}.2f")
print(f"Valor Final: R$ {valor_final:.2f}")
