senha = input("Digite uma senha: ")

while len(senha) < 8:
    print("Senha inválida! Deve ter no mínimo 8 caracteres.")
    senha = input("Digite novamente: ")

print("Senha validada e cadastrada com sucesso!")
