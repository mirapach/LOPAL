produto = input("Nome do produto: ")
qtd_atual = int(input("Quantidade atual em estoque: "))
qtd_vendida= int(input("Quantidade vendida: "))

estoque_restante = qtd_atual - qtd_vendida
print(f"\nProduto: {produto} | Estoque restante: {estoque_restante}")

if estoque_restante < 0:
    print("ALERTA: Estoque negativo: Necessário reabastecimento imediato.")
