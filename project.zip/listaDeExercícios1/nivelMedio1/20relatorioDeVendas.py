lista=[10,4,8,9,15,20,1,]
print("o maior valor " ,max(lista))
print("o menor valor " ,min(lista))
soma=0
for i in lista:
    soma+=i
print("total das vendas ",soma)
div = soma/7
print("A media é  " ,div)
