lista = ["chamada1", "chamada2", "chamada3"]
print(lista)
print("A chamada de número dois está sendo chamada")
lista.remove("chamada2")
print(lista)
