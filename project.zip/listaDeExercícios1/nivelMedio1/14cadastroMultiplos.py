lista_usuarios = []

for i in range(1,6):
    usuario = input(f"Digite o nome do usuário {i}: ")
    lista_usuarios.append(usuario)

for usuario in lista_usuarios:
    print(usuario)
