total_pares = 0

for i in range(1, 11):
    num = int(input("Digite o {i}°número inteiro: "))
    if num % 2 == 0:
        total_pares += 1

print(f"\nTotal de números pares digitados: {total_pares}")
