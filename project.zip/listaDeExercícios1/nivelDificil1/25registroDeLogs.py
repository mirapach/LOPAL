mensagens_log = [
    "Sistema iniciado\n",
    "Usuário autenticado\n",
    "Processo finalizado\n"
]

with open("log_sistema.txt", "w", encoding="utf-8") as arquivo_log:
    arquivo_log.writelines(mensagens_log)

print("Logs gravados com sucesso no arquivo 'log_sistemas.txt'.")
