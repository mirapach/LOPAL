sala = [
    ["L"], ["L"], ["L"],
    ["L"], ["L"], ["L"],
    ["L"], ["L"], ["L"]
]

print("  0  1  2")
for i in range(len(sala)):
    linha_formatada = " ".join(sala[i])
    print(f"{i} {linha_formatada}")
