megabytes = int(input("Digite o valor em MB: "))
kilobytes = megabytes * 1024
print("Valor em KB:", kilobytes)
