desenvolvedores = [
    "Mirella",
    "Kalebe",
    "Tiago",
    "Guilherme",
    "Kamilly"
]
for nome in desenvolvedores:
    print(nome)
