print("Digite a sua idade: ")
idade = int(input())
if idade >=18:
    print("Acesso permitido")
else:
    print("Acesso negado")
