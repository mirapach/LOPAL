user = input("Digite o nome de usuário: ")
senha = input("Digite sua senha: ")

if user == "admin" and senha == "1234":
    print("Login realizado com sucesso")
else:
    print("Credenciais inválidas")
