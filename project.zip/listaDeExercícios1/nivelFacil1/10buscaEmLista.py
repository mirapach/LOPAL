nome = ["Mirella", "Kalebe", "Tiago", "Pedro", "Kamilly"]

busca = input("Digite um nome: ")

if busca in nome:
    print("Nome encontrado!")
else:
    print("Nome não encontrado!")
