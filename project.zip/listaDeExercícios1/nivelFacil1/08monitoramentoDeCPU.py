cpu = 10

while cpu <= 100:
    print(f"Uso da CPU: {cpu}%")
    cpu += 10
