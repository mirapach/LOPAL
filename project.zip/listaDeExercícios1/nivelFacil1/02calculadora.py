credito1 = float(input("Digite o primeiro valor de créditos: "))
credito2 = float(input("Digite o segundo valor de créditos: "))

total = credito1 + credito2

print("Total de créditos disponíveis:", total)
